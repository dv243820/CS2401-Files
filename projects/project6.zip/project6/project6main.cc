/**
 *        @file: project6main.cc
 *      @author: Drew VanAtta
 *        @date: November 15, 2022
 *       @brief: Add Description
 */

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include "Othello.h"
using namespace std;
using namespace main_savitch_14;

/// function prototypes

int main()
{
    Othello mygame;
    mygame.play();
}